

import json, pickle
import json, re
from scipy import stats
import itertools
import numpy as np
from tqdm import tqdm
from itertools import combinations
from sklearn.metrics import cohen_kappa_score

def cohen_kappa_with_tolerance(rater1, rater2, tolerance=1):
  if len(rater1) != len(rater2):
    raise ValueError("Input lists must have the same length")



  adjusted_rater2 = []
  for i in range(len(rater1)):
    if abs(rater1[i] - rater2[i]) <= tolerance:
      adjusted_rater2.append(rater1[i])  # Assign the same value as rater1
    else:
      adjusted_rater2.append(rater2[i])  # Keep original rating


  return cohen_kappa_score(rater1, adjusted_rater2)


"""
============= labels from different annotators ==============
"""
preds, refs, inputs, grades = [],[],[],[]
with open(
  "../data/conala/conala_grade.json") as f:
  data_for_eval = json.load(f)
  conala_models_list = ['baseline', 'tranx-annot', 'best-tranx', 'best-tranx-rerank', 'codex']
for data in tqdm(data_for_eval):
  PROBLEM = data['intent']
  GT = data['snippet'][0]
  ks = conala_models_list
  for key_s in ks:
    CODE = data[key_s]
    GRADE = data['grade-'+key_s]
    inputs.append(PROBLEM)
    preds.append(CODE)
    refs.append(GT)
    grades.append(GRADE)
fixed_labels = grades
fixed_labels = [l+1 for l in fixed_labels]

annotator_grades = []
with open(
  '../data/conala/conala-human-grades.json') as f:
  data_example = json.load(f)
  conala_models_list = ['baseline', 'tranx-annot', 'best-tranx', 'best-tranx-rerank', 'codex']
for data in tqdm(data_example ):
  ks = conala_models_list
  for key_s in ks:
    GRADE = data['grade-' + key_s]
    annotator_grades.append(GRADE)


conala_data_ids = list(range(len(inputs)))

annotator_to_labels = {}

for i in range(len(conala_data_ids)):
    g = annotator_grades[i]
    for key_s in g:
      if key_s not in annotator_to_labels:
        annotator_to_labels[key_s] = []
      annotator_to_labels[key_s].append(  (i, g[key_s])  )
print()

"""
=============== 获取我们方法的prediction ==============
"""

def main_conala(DEBUG_CHOICE):

  DEBUG = DEBUG_CHOICE


  preds, refs, inputs, grades = [],[],[],[]
  with open(
    "../data/conala/conala_grade.json") as f:
    data_for_eval = json.load(f)
    conala_models_list = ['baseline', 'tranx-annot', 'best-tranx', 'best-tranx-rerank', 'codex']
  for data in tqdm(data_for_eval):
    PROBLEM = data['intent']
    GT = data['snippet'][0]
    ks = conala_models_list
    for key_s in ks:
      CODE = data[key_s]
      GRADE = data['grade-'+key_s]
      inputs.append(PROBLEM)
      preds.append(CODE)
      refs.append(GT)
      grades.append(GRADE)
  fixed_labels = grades
  fixed_labels = [l+1 for l in fixed_labels]

  with open(
          "../results//agent-score-direct_assess_no_gt-conala.pkl",
          "rb") as f:
    scores = pickle.load(f)
    conala_models_list = ['baseline', 'tranx-annot', 'best-tranx', 'best-tranx-rerank', 'codex']
    all_agents_scores1_1 = []
    for score in scores:
      for key_s in conala_models_list:
        all_agents_scores1_1.append(score['agent-' + key_s])


  with open(
    "../results//agent-score-direct_assess-conala.pkl",
    "rb") as f:
    scores = pickle.load(f)
    conala_models_list = ['baseline', 'tranx-annot', 'best-tranx', 'best-tranx-rerank', 'codex']
    all_agents_scores1_2 = []
    for score in scores:
      for key_s in conala_models_list :
        all_agents_scores1_2.append(score['agent-'+key_s])


  with open(
    "../results//agent-score-direct_compare-conala.pkl",
    "rb") as f:
    scores = pickle.load(f)
    conala_models_list = ['baseline', 'tranx-annot', 'best-tranx', 'best-tranx-rerank', 'codex']
    all_agents_scores2 = []
    for score in scores:
      for key_s in conala_models_list:
        all_agents_scores2.append(score['agent-' + key_s])


  with open(
    "../results/agent-score-test_gene_reason-conala.pkl",
    "rb") as f:
    scores = pickle.load(f)
    conala_models_list = ['baseline', 'tranx-annot', 'best-tranx', 'best-tranx-rerank', 'codex']
    all_agents_scores3 = []
    for score in scores:
      for key_s in conala_models_list:
        all_agents_scores3.append(score['agent-' + key_s])

  with open(
    "../results//agent-score-direct_assess_then_Validate-conala.pkl",
    "rb") as f:
    scores = pickle.load(f)
    conala_models_list = ['baseline', 'tranx-annot', 'best-tranx', 'best-tranx-rerank', 'codex']
    all_agents_scores4 = []
    for score in scores:
      for key_s in conala_models_list:
        all_agents_scores4.append(score['agent-' + key_s])

  with open(
    "../results/agent-score-analyze_gt_then_validate-conala.pkl",
    "rb") as f:
    scores = pickle.load(f)
    conala_models_list = ['baseline', 'tranx-annot', 'best-tranx', 'best-tranx-rerank', 'codex']
    all_agents_scores5 = []
    for score in scores:
      for key_s in conala_models_list:
        all_agents_scores5.append(score['agent-' + key_s])




  our_preds1_1, our_preds1_2, our_preds2, our_preds3, our_preds4, our_preds5 = [],[],[],[],[],[]

  for l in all_agents_scores1_1:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
    our_preds1_1.append(l)


  for l in all_agents_scores1_2:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
    our_preds1_2.append(l)

  for l in all_agents_scores2:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
    our_preds2.append(l)

  for l in all_agents_scores3:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
      if not isinstance(l, int):
        l = 0
    our_preds3.append(l)

  for l in all_agents_scores4:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
      if not isinstance(l, int):
        l = 0
    our_preds4.append(l)


  for l in all_agents_scores5:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
      if not isinstance(l, int):
        l = 0
    our_preds5.append(l)



  def map_score(old_score):
    return 1 + (old_score / 100) * 4

  our_preds1_1 = [map_score(l) for l in our_preds1_1]
  our_preds1_2 = [map_score(l) for l in our_preds1_2]
  our_preds2 = [map_score(l) for l in our_preds2]
  our_preds3 = [map_score(l) for l in our_preds3]
  our_preds4 = [map_score(l) for l in our_preds4]
  our_preds5 = [map_score(l) for l in our_preds5]

  NUM_EXAMPLES = 20


  # ================= Debug (START) =================
  import random
  random.seed(12345)
  indices = random.sample(range(len(our_preds1_1)), NUM_EXAMPLES)





  if DEBUG == 1:
    print("***** This Is Debugging Setting !! ******")
    our_preds1_1 = [our_preds1_1[i] for i in indices]
    our_preds1_2 = [our_preds1_2[i] for i in indices]
    our_preds2 = [our_preds2[i] for i in indices]
    our_preds3 = [our_preds3[i] for i in indices]
    our_preds4 = [our_preds4[i] for i in indices]
    our_preds5 = [our_preds5[i] for i in indices]
    fixed_labels = [fixed_labels[i] for i in indices]
  elif DEBUG == 0:
    pass ## deal with val set outside this function
  else:
    pass
  print(len(fixed_labels), len(our_preds1_1), len(our_preds2), len(our_preds3), len(our_preds4), len(our_preds5))

  # ================= Debug (END) =================


  our_preds_mapped1_1, our_preds_mapped1_2, our_preds_mapped2, our_preds_mapped3, our_preds_mapped4, our_preds_mapped5, our_preds_mapped_merged = [],[],[],[],[],[],[]
  for l in our_preds1_1:
    our_preds_mapped1_1.append(round(l))
  for l in our_preds1_2:
      our_preds_mapped1_2.append(round(l))
  for l in our_preds2:
    our_preds_mapped2.append(round(l))
  for l in our_preds3:
    our_preds_mapped3.append(round(l))
  for l in our_preds4:
    our_preds_mapped4.append(round(l))
  for l in our_preds5:
    our_preds_mapped5.append(round(l))


  if DEBUG == 1:


    list_data = {
      'S1_1': our_preds_mapped1_1,
      'S1_2': our_preds_mapped1_2,
      'S2': our_preds_mapped4,
      'S3': our_preds_mapped2,
      'S4': our_preds_mapped5,
      'S5': our_preds_mapped3,
    }



    lists = list(list_data.values())
    names = list(list_data.keys())

    combinations_data = []


    for r in range(2, len(lists) + 1):
      for indices in itertools.combinations(range(len(lists)), r):
        combo_lists = [lists[i] for i in indices]
        combo_names = [names[i] for i in indices]

        avg_list = np.mean(combo_lists, axis=0)
        avg_list = avg_list.tolist()
        avg_list = [ll for ll in avg_list]


        def compute(refs, preds):
          return stats.kendalltau(refs, preds).statistic, \
            stats.pearsonr(refs, preds).statistic, \
            stats.spearmanr(refs, preds).statistic


        kendalls, pearsons, spearmans = [], [], []
        kendall, pearson, spearman = compute(fixed_labels, avg_list)
        avg_cor = (kendall + spearman) / 2

        if 'S1_1' not in combo_names and 'S1_2' not in combo_names:
          pass
        else:
          combinations_data.append({
            'combination_names': combo_names,
            "combination": combo_lists,
            "merged": avg_list,
            "kendall": kendall,
            "pearson": pearson,
            "spearman": spearman,
            "avg_cor": avg_cor,
          })




    max_cor_combo = max(combinations_data, key=lambda x: x["avg_cor"])





    with open('../results/conala_selected.txt', 'w') as f:
        f.write('\n'.join(max_cor_combo['combination_names']))

  else:
    with open('../results/conala_selected.txt', 'r') as f:
      combination_names = f.readlines()
    combination_names = [ll.strip() for ll in combination_names]


    list_data = {
      'S1_1': our_preds_mapped1_1,
      'S1_2': our_preds_mapped1_2,
      'S2': our_preds_mapped4,
      'S3': our_preds_mapped2,
      'S4': our_preds_mapped5,
      'S5': our_preds_mapped3,
    }

    selected_lists = [list_data[name] for name in combination_names]
    avg_list = np.mean(selected_lists, axis=0)
    avg_list = avg_list.tolist()
    avg_list = [round(ll) for ll in avg_list]


    def compute(refs, preds):
      return stats.kendalltau(refs, preds).statistic, \
        stats.pearsonr(refs, preds).statistic, \
        stats.spearmanr(refs, preds).statistic

    kendall, pearson, spearman = compute(fixed_labels, avg_list)
    avg_cor = (kendall + spearman) / 2


    for one_name in list(list_data.keys()):
        selected_lists = [ list_data[one_name] ]
        avg_list = np.mean(selected_lists, axis=0)
        avg_list = avg_list.tolist()
        avg_list = [round(ll) for ll in avg_list]

        def compute(refs, preds):
          return stats.kendalltau(refs, preds).statistic, \
            stats.pearsonr(refs, preds).statistic, \
            stats.spearmanr(refs, preds).statistic

        kendall, pearson, spearman = compute(fixed_labels, avg_list)
        avg_cor = (kendall + spearman) / 2



    return indices, avg_list

## find the best team with 20 samples
main_conala(1)

# ## apply the best team with all rest data samples
RemoveSampleIndex, our_tool_preds = main_conala(0)



"""
=============== 计算不同人之间的agreement ==============
"""


annotators_list = ['grader1', 'grader2', 'grader3','grader4', 'grader5', 'grader6', 'grader7', 'grader8', 'grader9', 'grader10', 'grader11', 'grader12', 'grader13', 'grader14', 'grader15']
all_ids, all_labels = [],[]
for annotator in annotators_list:
  res = annotator_to_labels[annotator]
  sorted_res = sorted(res, key=lambda x: x[0])
  sorted_ids = [l[0] for l in sorted_res]
  all_ids.append(sorted_ids)
  all_labels.append([l[1] for l in sorted_res])



tool_preds_agreement = our_tool_preds
tool_preds_agreement_ids = list(range(len(tool_preds_agreement)))

print(0)


def compute_average_kappa(annotations, annotation_ids, tolerance=1):

  def get_intersection_with_indices(list1, list2):
    set2 = set(list2)
    intersection = []

    for i, item in enumerate(list1):
      if item in set2:
        j = list2.index(item)
        intersection.append((item, i, j))
    return intersection

  annotator_pairs = list(combinations(range(len(annotations)), 2))
  kappa_scores = []
  kappa_t_scores = []
  for i, j in annotator_pairs:
    annotation_ids_1 = annotation_ids[i]
    annotation_ids_2 = annotation_ids[j]
    annotations_1 = annotations[i]
    annotations_2 = annotations[j]

    common_data_points =  get_intersection_with_indices(annotation_ids_1, annotation_ids_2)
    intersected_annotation1,intersected_annotation2 = [],[]
    for _, index_in_i, index_in_j in common_data_points:
      intersected_annotation1.append(annotations_1[index_in_i])
      intersected_annotation2.append(annotations_2[index_in_j])

    if len(intersected_annotation1) <= 1:
      continue

    kappa = cohen_kappa_score(intersected_annotation1, intersected_annotation2)
    kappa_tolerance = cohen_kappa_with_tolerance(intersected_annotation1, intersected_annotation2, tolerance)

    kappa_scores.append(kappa)
    kappa_t_scores.append(kappa_tolerance)

  return sum(kappa_scores) / len(kappa_scores), sum(kappa_t_scores) / len(kappa_t_scores), kappa_scores, kappa_t_scores

def compute_tool_human_kappa(human_annotations, human_annotation_ids, tool_annotation, tool_annotation_ids, tolerance=1):
  def get_intersection_with_indices(list1, list2):
    set2 = set(list2)
    intersection = []

    for i, item in enumerate(list1):
      if item in set2:
        j = list2.index(item)
        intersection.append((item, i, j))
    return intersection

  kappa_scores = []
  kappa_t_scores = []
  for i in range(len(human_annotations)):
    human_data = human_annotations[i]
    human_data_id = human_annotation_ids[i]

    common_data_points = get_intersection_with_indices(human_data_id, tool_annotation_ids)
    intersected_annotation1, intersected_annotation2 = [], []
    for _, index_in_i, index_in_j in common_data_points:
      intersected_annotation1.append(human_data[index_in_i])
      intersected_annotation2.append(tool_annotation[index_in_j])
    if len(intersected_annotation1) <= 1:
      continue

    kappa = cohen_kappa_score(intersected_annotation1, intersected_annotation2)
    kappa_tolerance = cohen_kappa_with_tolerance(intersected_annotation1, intersected_annotation2, tolerance)

    kappa_scores.append(kappa)
    kappa_t_scores.append(kappa_tolerance)



  return sum(kappa_scores) / len(kappa_scores), sum(kappa_t_scores) / len(kappa_t_scores), kappa_scores, kappa_t_scores



human_annotations = all_labels
human_annotations_ids = all_ids
tool_annotation = [ l-1 for l in tool_preds_agreement]
tool_annotation_ids = tool_preds_agreement_ids


for i_index in sorted(RemoveSampleIndex, reverse=True):
  _ = tool_annotation.pop(i_index)
  _ = tool_annotation_ids.pop(i_index)






human_kappa, human_kappa_t, human_individual_kappa, _ = compute_average_kappa(human_annotations, human_annotations_ids)
print("Average Human-Human Cohen's Kappa:", human_kappa)


tool_human_kappa, tool_human_kappa_t, tool_human_individual_kappa, _= compute_tool_human_kappa(human_annotations, human_annotations_ids, tool_annotation, tool_annotation_ids)
print("Average Tool-Human Cohen's Kappa:", tool_human_kappa)






