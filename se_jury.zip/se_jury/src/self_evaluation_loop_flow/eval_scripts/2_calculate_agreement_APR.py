
import pickle, json, re
import pandas as pd
import itertools
from itertools import combinations
from sklearn.metrics import cohen_kappa_score
import numpy as np
from scipy import stats

"""
============= APR labels from different annotators ==============
"""
label_data = pd.read_csv('../data/apr/bach_label.csv')
annotator_ids = label_data['Annotator'].to_list()
patch_ids = label_data['Patch'].to_list()
answers = label_data['Answer'].to_list()

annotator_to_labels = {}
patch_id_to_labels = {}
for i in range(len(patch_ids)):
    annotator_id = annotator_ids[i]
    patch_id = patch_ids [i]
    answer = answers[i]
    if patch_id not in patch_id_to_labels:
      patch_id_to_labels[patch_id] = []
    patch_id_to_labels[patch_id].append( (annotator_id, answer)  )
    if annotator_id not in annotator_to_labels:
      annotator_to_labels[annotator_id] = []
    annotator_to_labels[annotator_id].append( (patch_id, answer) )




if True:

  with open(
    '../data/apr/bach_data.pkl',
    'rb') as f:
    all_patch_id, all_project_name, all_bug_id, all_failed_tests, all_failed_tests_name_list, all_failed_tests_content_list, all_tests, all_human_patch, all_tool_patch_author_label, all_tool_patch = pickle.load(f)
    all_author_labels = all_tool_patch_author_label


def main_apr(DEBUG_CHOICE):

  DEBUG = DEBUG_CHOICE

  label_data = pd.read_csv('../data/apr/bach_label.csv')
  annotator_ids = label_data['Annotator'].to_list()
  patch_ids = label_data['Patch'].to_list()
  answers = label_data['Answer'].to_list()

  patch_id_to_labels = {}
  for i in range(len(patch_ids)):
    annotator_id = annotator_ids[i]
    patch_id = patch_ids [i]
    answer = answers[i]
    if patch_id not in patch_id_to_labels:
      patch_id_to_labels[patch_id] = []
    patch_id_to_labels[patch_id].append( (annotator_id, answer)  )


  with open(
    '../data/apr/bach_data.pkl',
    'rb') as f:
    all_patch_id, all_project_name, all_bug_id, all_failed_tests, all_failed_tests_name_list, all_failed_tests_content_list, all_tests, all_human_patch, all_tool_patch_author_label, all_tool_patch = pickle.load(f)
    all_author_labels = all_tool_patch_author_label



  fixed_labels = []
  for i in range(len(all_patch_id)):
    patch_id = int(all_patch_id[i])
    mutil_annotator_results = patch_id_to_labels[patch_id]
    tool_author_label  = all_tool_patch_author_label[i].strip()
    maps = {'Y': 1, 'N': 0, '0': 0}
    votes = [maps[l[1]] for l in mutil_annotator_results]


    if votes.count(1) >= (len(votes)*0.5):
      fixed_labels.append(1)
    else:
      fixed_labels.append(0)

  with open(
    "../results/agent-score-direct_assess_no_gt-apr.pkl",
    "rb") as f:
    all_agents_scores1_1 = pickle.load(f)


  with open(
    "../results/agent-score-direct_assess-apr.pkl",
    "rb") as f:
    all_agents_scores1_2 = pickle.load(f)

  with open(
    "../results/agent-score-direct_compare-apr.pkl",
    "rb") as f:
    all_agents_scores2 = pickle.load(f)

  with open(
    "../results/agent-score-test_gene_reason-apr.pkl",
    "rb") as f:
    all_agents_scores3 = pickle.load(f)

  with open(
    "../results/agent-score-direct_assess_then_Validate-apr.pkl",
    "rb") as f:
    all_agents_scores4 = pickle.load(f)

  with open(
    "../results/agent-score-analyze_gt_then_validate-apr.pkl",
    "rb") as f:
    all_agents_scores5 = pickle.load(f)




  our_preds1_1, our_preds1_2, our_preds2, our_preds3, our_preds4, our_preds5 = [],[],[],[],[],[]

  for l in all_agents_scores1_1:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
    our_preds1_1.append(l)

  for l in all_agents_scores1_2:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
    our_preds1_2.append(l)

  for l in all_agents_scores2:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
    our_preds2.append(l)

  for l in all_agents_scores3:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
      if not isinstance(l, int):
        l = 0
    our_preds3.append(l)

  for l in all_agents_scores4:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
      if not isinstance(l, int):
        l = 0
    our_preds4.append(l)


  for l in all_agents_scores5:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
      if not isinstance(l, int):
        l = 0
    our_preds5.append(l)


  def map_score(old_score):
    return 1 + (old_score / 100) * 4


  our_preds1_1 = [map_score(l) for l in our_preds1_1]
  our_preds1_2 = [map_score(l) for l in our_preds1_2]
  our_preds2 = [map_score(l) for l in our_preds2]
  our_preds3 = [map_score(l) for l in our_preds3]
  our_preds4 = [map_score(l) for l in our_preds4]
  our_preds5 = [map_score(l) for l in our_preds5]


  import random
  random.seed(12345)
  NUM_EXAMPLES = 20


  indices = random.sample(range(len(our_preds1_1)), NUM_EXAMPLES)


  our_preds1_1_all = our_preds1_1.copy()
  our_preds1_2_all = our_preds1_2.copy()
  our_preds2_all = our_preds2.copy()
  our_preds3_all = our_preds3.copy()
  our_preds4_all = our_preds4.copy()
  our_preds5_all = our_preds5.copy()
  fixed_labels_all = fixed_labels.copy()

  if DEBUG == 1:
    print("***** This Is Debugging Setting !! ******")

    our_preds1_1 = [our_preds1_1[i] for i in indices]
    our_preds1_2 = [our_preds1_2[i] for i in indices]
    our_preds2 = [our_preds2[i] for i in indices]
    our_preds3 = [our_preds3[i] for i in indices]
    our_preds4 = [our_preds4[i] for i in indices]
    our_preds5 = [our_preds5[i] for i in indices]
    fixed_labels = [fixed_labels[i] for i in indices]

  elif DEBUG == 0:
    print("***** This Is TEST Setting !! ******")

    our_preds1_1 = [our_preds1_1[i] for i in range(len(our_preds1_1)) if i not in indices]
    our_preds1_2= [our_preds1_2[i] for i in range(len(our_preds1_2)) if i not in indices]
    our_preds2 = [our_preds2[i] for i in range(len(our_preds2)) if i not in indices]
    our_preds3 = [our_preds3[i] for i in range(len(our_preds3)) if i not in indices]
    our_preds4 = [our_preds4[i] for i in range(len(our_preds4)) if i not in indices]
    our_preds5 = [our_preds5[i] for i in range(len(our_preds5)) if i not in indices]
    fixed_labels = [fixed_labels[i] for i in range(len(fixed_labels)) if i not in indices]
  else:
    pass



  if DEBUG == 1:

    list_data = {
      'S1_1': our_preds1_1,
      'S1_2': our_preds1_2,
      'S2': our_preds4,
      'S3': our_preds2,
      'S4': our_preds5,
      'S5': our_preds3,
    }


    lists = list(list_data.values())
    names = list(list_data.keys())

    combinations_data = []


    for r in range(2, len(lists) + 1):

      for indices in itertools.combinations(range(len(lists)), r):

        combo_lists = [lists[i] for i in indices]
        combo_names = [names[i] for i in indices]

        avg_list_ = np.mean(combo_lists, axis=0)
        avg_list_ = avg_list_.tolist()
        avg_list = []
        for ll in avg_list_:
          if ll>3.0:
            avg_list.append(1)
          else:
            avg_list.append(0)



        def compute(refs, preds):
          return stats.kendalltau(refs, preds).statistic, \
            stats.pearsonr(refs, preds).statistic, \
            stats.spearmanr(refs, preds).statistic

        # Correlation
        kendalls, pearsons, spearmans = [], [], []
        kendall, pearson, spearman = compute(fixed_labels, avg_list)
        avg_cor = (kendall + spearman) / 2

        if 'S1_1' not in combo_names and 'S1_2' not in combo_names:
          pass

        else:
          combinations_data.append({
            'combination_names': combo_names,
            "combination": combo_lists,
            "merged": avg_list,
            "kendall": kendall,
            "pearson": pearson,
            "spearman": spearman,
            "avg_cor": avg_cor,
          })


    max_cor_combo = max(combinations_data, key=lambda x: x["avg_cor"])



    with open('../results/apr_selected.txt', 'w') as f:
        f.write('\n'.join(max_cor_combo['combination_names']))
    return {}


  else:
    with open(
      '../results/apr_selected.txt',
      'r') as f:
      combination_names = f.readlines()
    combination_names = [ll.strip() for ll in combination_names]


    list_data = {
      'S1_1': our_preds1_1_all,
      'S1_2': our_preds1_2_all,
      'S2': our_preds4_all,
      'S3': our_preds2_all,
      'S4': our_preds5_all,
      'S5': our_preds3_all,
    }

    selected_lists = [list_data[name] for name in combination_names]
    avg_list_ = np.mean(selected_lists, axis=0)
    avg_list_ = avg_list_.tolist()
    avg_list = []
    for ll in avg_list_:
      if ll >3.0:
        avg_list.append(1)
      else:
        avg_list.append(0)




    def compute(refs, preds):
      return stats.kendalltau(refs, preds).statistic, \
        stats.pearsonr(refs, preds).statistic, \
        stats.spearmanr(refs, preds).statistic

    kendall, pearson, spearman = compute(fixed_labels_all, avg_list)
    avg_cor = (kendall + spearman) / 2


  return indices, avg_list


## find the best team with 20 samples
main_apr(1)

# # ## apply the best team with all rest data samples
RemoveSampleIndex, our_tool_preds = main_apr(0)

our_patch_ids = all_patch_id
RemovePatchID = [our_patch_ids[l] for l in RemoveSampleIndex]


our_patch_res = {}
for i in range(len(our_patch_ids)):
  id_ = our_patch_ids [i]
  our_patch_res[id_] = our_tool_preds[i]



maps = {'Y': 1, 'N': 0, '0': 0}
G1_annotators = ['G1-P1', 'G1-P2', 'G1-P3', 'G1-P4']
G2_annotators = ['G2-P1', 'G2-P2', 'G2-P3', 'G2-P4', 'G2-P5']
G3_annotators = ['G3-P1', 'G3-P2', 'G3-P3', 'G3-P4', 'G3-P5', 'G3-P6', 'G3-P7', 'G3-P8']
G4_annotators = ['G4-P1', 'G4-P2', 'G4-P3', 'G4-P4', 'G4-P5', 'G4-P6', 'G4-P7']
G5_annotators = ['G5-P1', 'G5-P2', 'G5-P3', 'G5-P4', 'G5-P5', 'G5-P6']
G6_annotators = ['G6-P1', 'G6-P2', 'G6-P3', 'G6-P4', 'G6-P5', 'G6-P6']
G7_annotators = ['G7-P1', 'G7-P2', 'G7-P3', 'G7-P4', 'G7-P5']

agreements_among_human, agreements_tool_human = [],[]
for G_I_annotators in [G1_annotators, G2_annotators, G3_annotators, G4_annotators, G5_annotators, G6_annotators, G7_annotators]:

  ids, labels = [],[]
  for annotator in G_I_annotators:
    res = annotator_to_labels[annotator]
    sorted_res = sorted(res, key=lambda x: x[0])
    sorted_patch_ids, sorted_labels =[],[]
    for i in range(len(sorted_res)):
      if str(sorted_res[i][0]) not in  RemovePatchID:
        sorted_patch_ids.append(sorted_res[i][0])
        sorted_labels.append(maps[sorted_res[i][1]])

    ids.append(sorted_patch_ids)
    labels.append(sorted_labels)

  tool_preds_agreement = []
  for id_ in ids[0]:
    tool_preds_agreement.append(our_patch_res[str(id_)])



  def compute_average_kappa(annotations):
    annotator_pairs = list(combinations(range(len(annotations)), 2))
    kappa_scores = []

    for i, j in annotator_pairs:
      kappa = cohen_kappa_score(annotations[i], annotations[j])
      kappa_scores.append(kappa)
    return sum(kappa_scores) / len(kappa_scores)
  def compute_tool_human_kappa(human_annotations, tool_annotation):
    kappa_scores = [cohen_kappa_score(human, tool_annotation) for human in human_annotations]
    return sum(kappa_scores) / len(kappa_scores)



  human_annotations = labels
  tool_annotation = tool_preds_agreement


  human_kappa = compute_average_kappa(human_annotations)
  tool_human_kappa= compute_tool_human_kappa(human_annotations, tool_annotation)

  agreements_among_human.append(human_kappa)
  agreements_tool_human.append(tool_human_kappa)

print('Human-Human Average:', sum(agreements_among_human)/len(agreements_among_human))
print('Tool-Human Average:', sum(agreements_tool_human)/len(agreements_tool_human))



