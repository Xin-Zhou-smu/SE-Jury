
import json, pickle, re
from scipy import stats
from tqdm import tqdm
import itertools
import numpy as np

import random

def main_summary(DEBUG_CHOICE):
  DEBUG = DEBUG_CHOICE
  NUM_EXAMPLES = 20


  import pandas as pd
  df = pd.read_csv(
    '../data/summarization/human-annotated-dataset-with-metrics.csv')
  user_ids = df['user_id'].tolist()
  texts = df['codeComment'].tolist()
  grades = df['Content Adequacy'].tolist()

  existing_preds = []
  preds_to_ids = {}
  idx = 0
  for l in texts:
    if l not in existing_preds:
      preds_to_ids[l] = idx
      idx +=1
      existing_preds.append(l)
    else:
      continue

  unique_pred_data_ids = []
  for l in texts:
    unique_pred_data_ids.append(preds_to_ids[l])


  def extract_annotations(problem_ids, annotator_names, grades_list):
      all_results = {}
      idx = 0
      for pid, annotator, grade in zip(problem_ids, annotator_names, grades_list):
        if pid not in all_results:
          all_results[pid] = {}
        all_results[pid][annotator] = grade
        idx += 1
      return all_results

  annotator_uni_names = {}
  idx = 1
  for l in user_ids:
    if l not in annotator_uni_names:
      annotator_uni_names[l] = 'grader-'+ str(idx)
      idx +=1
  annotator_names = [annotator_uni_names[l] for l in user_ids]
  grades_list = grades
  annotations_per_person = extract_annotations(unique_pred_data_ids, annotator_names, grades_list)
  combined_grades = {}
  for pid in annotations_per_person:
    res = [annotations_per_person[pid][key] for key in annotations_per_person[pid]]
    combined_grades[pid] = round(sum(res)/len(res))


  preds_index_in_original_data_with_unique_ids = []
  preds_indexes = []
  labels_index_in_original_data_with_unique_ids = []
  existing_preds = []
  for idx in range(len(texts)):
    l = texts[idx]
    if l not in existing_preds:
      preds_index_in_original_data_with_unique_ids.append(idx)
      preds_indexes.append(preds_to_ids[l])
      labels_index_in_original_data_with_unique_ids.append(combined_grades[preds_to_ids[l]])
      existing_preds.append(l)



  preds, refs, inputs, grades = [],[],[],[]
  import pandas as pd
  df = pd.read_csv(
    '../data/summarization/human-annotated-dataset-with-metrics.csv')
  codes = df['codeFunctions'].tolist()
  texts = df['codeComment'].tolist()
  gold_texts = df['originalComment'].tolist()
  all_agents_scores = []
  ijk = 0
  grades = []
  for ijk in tqdm(range(len(codes))):
    if ijk in preds_index_in_original_data_with_unique_ids:
      CODE = codes[ijk]
      TEXT = texts[ijk]
      GT = gold_texts[ijk]
      SCORE = combined_grades[preds_to_ids[TEXT]]
      grades.append(SCORE)
      inputs.append(CODE)
      preds.append(TEXT)
      refs.append(GT)
  fixed_labels = grades

  with open(
    "../results/agent-score-direct_assess_no_gt-summarization.pkl",
    "rb") as f:
    all_agents_scores1_1= pickle.load(f)


  with open(
    "../results/agent-score-direct_assess-summarization.pkl",
    "rb") as f:
    all_agents_scores1_2= pickle.load(f)


  with open(
    "../results/agent-score-direct_compare-summarization.pkl",
    "rb") as f:
    all_agents_scores2= pickle.load(f)


  with open(
    "../results/agent-score-direct_assess_then_Validate-summarization.pkl",
    "rb") as f:
    all_agents_scores4= pickle.load(f)

  with open(
    "../results/agent-score-analyze_gt_then_validate-summarization.pkl",
    "rb") as f:
    all_agents_scores5= pickle.load(f)


  our_preds1_1, our_preds1_2, our_preds2, our_preds3, our_preds4, our_preds5 = [],[],[],[],[],[]

  for l in all_agents_scores1_1:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
    our_preds1_1.append(l)


  for l in all_agents_scores1_2:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
    our_preds1_2.append(l)

  for l in all_agents_scores2:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
    our_preds2.append(l)


  for l in all_agents_scores4:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
      if not isinstance(l, int):
        l = 0
    our_preds4.append(l)


  for l in all_agents_scores5:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
      if not isinstance(l, int):
        l = 0
    our_preds5.append(l)

  new_our_preds1_1 = []
  for ijk in tqdm(range(len(our_preds1_1))):
    if ijk in preds_index_in_original_data_with_unique_ids:
      new_our_preds1_1.append(our_preds1_1[ijk])
  del our_preds1_1
  our_preds1_1 = new_our_preds1_1
  del new_our_preds1_1


  new_our_preds1_2 = []
  for ijk in tqdm(range(len(our_preds1_2))):
    if ijk in preds_index_in_original_data_with_unique_ids:
      new_our_preds1_2.append(our_preds1_2[ijk])
  del our_preds1_2
  our_preds1_2 = new_our_preds1_2
  del new_our_preds1_2

  new_our_preds2 = []
  for ijk in tqdm(range(len(our_preds2))):
    if ijk in preds_index_in_original_data_with_unique_ids:
      new_our_preds2.append(our_preds2[ijk])
  del our_preds2
  our_preds2 = new_our_preds2
  del new_our_preds2

  new_our_preds3 = []
  for ijk in tqdm(range(len(our_preds3))):
    if ijk in preds_index_in_original_data_with_unique_ids:
      new_our_preds3.append(our_preds3[ijk])
  del our_preds3
  our_preds3 = new_our_preds3
  del new_our_preds3


  new_our_preds4 = []
  for ijk in tqdm(range(len(our_preds4))):
    if ijk in preds_index_in_original_data_with_unique_ids:
      new_our_preds4.append(our_preds4[ijk])
  del our_preds4
  our_preds4 = new_our_preds4
  del new_our_preds4

  new_our_preds5 = []
  for ijk in tqdm(range(len(our_preds5))):
    if ijk in preds_index_in_original_data_with_unique_ids:
      new_our_preds5.append(our_preds5[ijk])
  del our_preds5
  our_preds5 = new_our_preds5
  del new_our_preds5


  def map_score(old_score):
    return 1 + (old_score / 100) * 4


  our_preds1_1 = [map_score(l) for l in our_preds1_1]
  our_preds1_2 = [map_score(l) for l in our_preds1_2]
  our_preds2 = [map_score(l) for l in our_preds2]
  our_preds4 = [map_score(l) for l in our_preds4]
  our_preds5 = [map_score(l) for l in our_preds5]
  # ================= Debug (START) =================
  random.seed(12345)
  indices = random.sample(range(len(our_preds1_2)), NUM_EXAMPLES)

  if DEBUG == 1:
    print("***** This Is Debugging Setting !! ******")
    our_preds1_1 = [our_preds1_1[i] for i in indices]
    our_preds1_2 = [our_preds1_2[i] for i in indices]
    our_preds2 = [our_preds2[i] for i in indices]
    our_preds4 = [our_preds4[i] for i in indices]
    our_preds5 = [our_preds5[i] for i in indices]
    fixed_labels = [fixed_labels[i] for i in indices]
  elif DEBUG == 0:
    print("***** This Is TEST Setting !! ******")
    our_preds1_1 = [our_preds1_1[i] for i in range(len(our_preds1_1)) if i not in indices]
    our_preds1_2= [our_preds1_2[i] for i in range(len(our_preds1_2)) if i not in indices]
    our_preds2 = [our_preds2[i] for i in range(len(our_preds2)) if i not in indices]
    our_preds4 = [our_preds4[i] for i in range(len(our_preds4)) if i not in indices]
    our_preds5 = [our_preds5[i] for i in range(len(our_preds5)) if i not in indices]
    fixed_labels = [fixed_labels[i] for i in range(len(fixed_labels)) if i not in indices]
  else:
    pass
  print(len(fixed_labels), len(our_preds1_1), len(our_preds2), len(our_preds4), len(our_preds5))

  # ================= Debug (END) =================


  our_preds_mapped1_1, our_preds_mapped1_2, our_preds_mapped2, our_preds_mapped3, our_preds_mapped4, our_preds_mapped5, our_preds_mapped_merged = [],[],[],[],[],[],[]

  for l in our_preds1_1:
      our_preds_mapped1_1.append(round(l))
  for l in our_preds1_2:
      our_preds_mapped1_2.append(round(l))
  for l in our_preds2:
    our_preds_mapped2.append(round(l))
  for l in our_preds4:
    our_preds_mapped4.append(round(l))
  for l in our_preds5:
    our_preds_mapped5.append(round(l))


  if DEBUG == 1:

    list_data = {
      'S1_1': our_preds_mapped1_1,
      'S1_2': our_preds_mapped1_2,
      'S2': our_preds_mapped4,
      'S3': our_preds_mapped2,
      'S4': our_preds_mapped5,
    }

    lists = list(list_data.values())
    names = list(list_data.keys())

    combinations_data = []

    for r in range(2, len(lists) + 1):
      for indices in itertools.combinations(range(len(lists)), r):
        combo_lists = [lists[i] for i in indices]
        combo_names = [names[i] for i in indices]

        avg_list = np.mean(combo_lists, axis=0)
        avg_list = avg_list.tolist()
        avg_list = [round(ll) for ll in avg_list]


        def compute(refs, preds):
          return stats.kendalltau(refs, preds).statistic, \
            stats.pearsonr(refs, preds).statistic, \
            stats.spearmanr(refs, preds).statistic


        kendalls, pearsons, spearmans = [], [], []
        kendall, pearson, spearman = compute(fixed_labels, avg_list)
        avg_cor = (kendall + spearman) / 2

        if 'S1_1' not in combo_names and 'S1_2' not in combo_names:
          pass
        else:
          combinations_data.append({
            'combination_names': combo_names,
            "combination": combo_lists,
            "merged": avg_list,
            "kendall": kendall,
            "pearson": pearson,
            "spearman": spearman,
            "avg_cor": avg_cor,
          })

    max_cor_combo = max(combinations_data, key=lambda x: x["avg_cor"])

    with open('../results/summarization_selected.txt', 'w') as f:
        f.write('\n'.join(max_cor_combo['combination_names']))
    return {}


  else:
    with open(
      '../results/summarization_selected.txt',
      'r') as f:
      combination_names = f.readlines()
    combination_names = [ll.strip() for ll in combination_names]


    list_data = {
      'S1_1': our_preds_mapped1_1,
      'S1_2': our_preds_mapped1_2,
      'S2': our_preds_mapped4,
      'S3': our_preds_mapped2,
      'S4': our_preds_mapped5,
    }

    selected_lists = [list_data[name] for name in combination_names]
    avg_list = np.mean(selected_lists, axis=0)
    avg_list = avg_list.tolist()
    avg_list = [ll for ll in avg_list]


    def compute(refs, preds):
      return stats.kendalltau(refs, preds).statistic, \
        stats.pearsonr(refs, preds).statistic, \
        stats.spearmanr(refs, preds).statistic

    kendall, pearson, spearman = compute(fixed_labels, avg_list)
    avg_cor = (kendall + spearman) / 2
    print({'combination_names': combination_names, "kendall": round(kendall, 3),
           "spearman": round(spearman, 3), "avg_cor": round(avg_cor, 3)})







## find the best team with 20 samples
main_summary(1)

# ## apply the best team with all rest data samples
main_summary(0)