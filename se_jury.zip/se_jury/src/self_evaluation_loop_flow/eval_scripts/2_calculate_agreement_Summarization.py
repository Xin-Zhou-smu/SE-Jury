import pickle, re
import pandas as pd
from scipy import stats
import itertools
from itertools import combinations
from sklearn.metrics import cohen_kappa_score
def cohen_kappa_with_tolerance(rater1, rater2, tolerance=1):
  if len(rater1) != len(rater2):
    raise ValueError("Input lists must have the same length")
  adjusted_rater2 = []
  for i in range(len(rater1)):
    if abs(rater1[i] - rater2[i]) <= tolerance:
      adjusted_rater2.append(rater1[i])
    else:
      adjusted_rater2.append(rater2[i])
  return cohen_kappa_score(rater1, adjusted_rater2)

"""
=========  Map individual grades into averaged grades
"""

df = pd.read_csv('../data/summarization/human-annotated-dataset-with-metrics.csv')
question_ids = df['question_id'].tolist()
user_ids = df['user_id'].tolist()
codes = df['codeFunctions'].tolist()
texts = df['codeComment'].tolist()
gold_texts = df['originalComment'].tolist()
grades = df['Content Adequacy'].tolist()

existing_preds = []
preds_to_ids = {}
idx = 0
for l in texts:
  if l not in existing_preds:
    preds_to_ids[l] = idx
    idx +=1
    existing_preds.append(l)
  else:
    continue

unique_pred_data_ids = []
for l in texts:
  unique_pred_data_ids.append(preds_to_ids[l])


def extract_annotations(problem_ids, annotator_names, grades_list):
    all_results = {}
    idx = 0
    for pid, annotator, grade in zip(problem_ids, annotator_names, grades_list):
      if pid not in all_results:
        all_results[pid] = {}
      all_results[pid][annotator] = grade
      idx += 1
    return all_results

annotator_uni_names = {}
idx = 1
for l in user_ids:
  if l not in annotator_uni_names:
    annotator_uni_names[l] = 'grader-'+ str(idx)
    idx +=1
annotator_names = [annotator_uni_names[l] for l in user_ids]
grades_list = grades
annotations_per_person = extract_annotations(unique_pred_data_ids, annotator_names, grades_list)
combined_grades = {}
for pid in annotations_per_person:
  res = [annotations_per_person[pid][key] for key in annotations_per_person[pid]]
  combined_grades[pid] = round(sum(res)/len(res))


preds_index_in_original_data_with_unique_ids = []
preds_indexes = []
labels_index_in_original_data_with_unique_ids = []
existing_preds = []
for idx in range(len(texts)):
  l = texts[idx]
  if l not in existing_preds:
    preds_index_in_original_data_with_unique_ids.append(idx)
    preds_indexes.append(preds_to_ids[l])
    labels_index_in_original_data_with_unique_ids.append(combined_grades[preds_to_ids[l]])
    existing_preds.append(l)




"""
Our Prediction
"""

from tqdm import tqdm
import itertools
import numpy as np

import random

def main_summary(DEBUG_CHOICE):
  DEBUG = DEBUG_CHOICE

  NUM_EXAMPLES = 20



  import pandas as pd
  df = pd.read_csv(
    '../data/summarization/human-annotated-dataset-with-metrics.csv')
  user_ids = df['user_id'].tolist()
  texts = df['codeComment'].tolist()
  grades = df['Content Adequacy'].tolist()

  existing_preds = []
  preds_to_ids = {}
  idx = 0
  for l in texts:
    if l not in existing_preds:
      preds_to_ids[l] = idx
      idx +=1
      existing_preds.append(l)
    else:
      continue

  unique_pred_data_ids = []
  for l in texts:
    unique_pred_data_ids.append(preds_to_ids[l])


  def extract_annotations(problem_ids, annotator_names, grades_list):
      all_results = {}
      idx = 0
      for pid, annotator, grade in zip(problem_ids, annotator_names, grades_list):
        if pid not in all_results:
          all_results[pid] = {}
        all_results[pid][annotator] = grade
        idx += 1
      return all_results

  annotator_uni_names = {}
  idx = 1
  for l in user_ids:
    if l not in annotator_uni_names:
      annotator_uni_names[l] = 'grader-'+ str(idx)
      idx +=1
  annotator_names = [annotator_uni_names[l] for l in user_ids]
  grades_list = grades
  annotations_per_person = extract_annotations(unique_pred_data_ids, annotator_names, grades_list)
  combined_grades = {}
  for pid in annotations_per_person:
    res = [annotations_per_person[pid][key] for key in annotations_per_person[pid]]
    combined_grades[pid] = round(sum(res)/len(res))


  preds_index_in_original_data_with_unique_ids = []
  preds_indexes = []
  labels_index_in_original_data_with_unique_ids = []
  existing_preds = []
  for idx in range(len(texts)):
    l = texts[idx]
    if l not in existing_preds:
      preds_index_in_original_data_with_unique_ids.append(idx)
      preds_indexes.append(preds_to_ids[l])
      labels_index_in_original_data_with_unique_ids.append(combined_grades[preds_to_ids[l]])
      existing_preds.append(l)







  preds, refs, inputs, grades = [],[],[],[]
  import pandas as pd
  df = pd.read_csv(
    '../data/summarization/human-annotated-dataset-with-metrics.csv')
  codes = df['codeFunctions'].tolist()
  texts = df['codeComment'].tolist()
  gold_texts = df['originalComment'].tolist()
  all_agents_scores = []
  ijk = 0
  grades = []
  for ijk in tqdm(range(len(codes))):
    if ijk in preds_index_in_original_data_with_unique_ids:
      CODE = codes[ijk]
      TEXT = texts[ijk]
      GT = gold_texts[ijk]
      SCORE = combined_grades[preds_to_ids[TEXT]]
      grades.append(SCORE)
      inputs.append(CODE)
      preds.append(TEXT)
      refs.append(GT)
  fixed_labels = grades

  with open(
    "../results/agent-score-direct_assess_no_gt-summarization.pkl",
    "rb") as f:
    all_agents_scores1_1= pickle.load(f)


  with open(
    "../results/agent-score-direct_assess-summarization.pkl",
    "rb") as f:
    all_agents_scores1_2= pickle.load(f)


  with open(
    "../results/agent-score-direct_compare-summarization.pkl",
    "rb") as f:
    all_agents_scores2= pickle.load(f)


  with open(
    "../results/agent-score-direct_assess_then_Validate-summarization.pkl",
    "rb") as f:
    all_agents_scores4= pickle.load(f)

  with open(
    "../results/agent-score-analyze_gt_then_validate-summarization.pkl",
    "rb") as f:
    all_agents_scores5= pickle.load(f)


  our_preds1_1, our_preds1_2, our_preds2, our_preds3, our_preds4, our_preds5 = [],[],[],[],[],[]

  for l in all_agents_scores1_1:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
    our_preds1_1.append(l)


  for l in all_agents_scores1_2:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
    our_preds1_2.append(l)

  for l in all_agents_scores2:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
    our_preds2.append(l)


  for l in all_agents_scores4:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
      if not isinstance(l, int):
        l = 0
    our_preds4.append(l)


  for l in all_agents_scores5:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
      if not isinstance(l, int):
        l = 0
    our_preds5.append(l)

  new_our_preds1_1 = []
  for ijk in tqdm(range(len(our_preds1_1))):
    if ijk in preds_index_in_original_data_with_unique_ids:
      new_our_preds1_1.append(our_preds1_1[ijk])
  del our_preds1_1
  our_preds1_1 = new_our_preds1_1
  del new_our_preds1_1


  new_our_preds1_2 = []
  for ijk in tqdm(range(len(our_preds1_2))):
    if ijk in preds_index_in_original_data_with_unique_ids:
      new_our_preds1_2.append(our_preds1_2[ijk])
  del our_preds1_2
  our_preds1_2 = new_our_preds1_2
  del new_our_preds1_2

  new_our_preds2 = []
  for ijk in tqdm(range(len(our_preds2))):
    if ijk in preds_index_in_original_data_with_unique_ids:
      new_our_preds2.append(our_preds2[ijk])
  del our_preds2
  our_preds2 = new_our_preds2
  del new_our_preds2

  new_our_preds3 = []
  for ijk in tqdm(range(len(our_preds3))):
    if ijk in preds_index_in_original_data_with_unique_ids:
      new_our_preds3.append(our_preds3[ijk])
  del our_preds3
  our_preds3 = new_our_preds3
  del new_our_preds3


  new_our_preds4 = []
  for ijk in tqdm(range(len(our_preds4))):
    if ijk in preds_index_in_original_data_with_unique_ids:
      new_our_preds4.append(our_preds4[ijk])
  del our_preds4
  our_preds4 = new_our_preds4
  del new_our_preds4

  new_our_preds5 = []
  for ijk in tqdm(range(len(our_preds5))):
    if ijk in preds_index_in_original_data_with_unique_ids:
      new_our_preds5.append(our_preds5[ijk])
  del our_preds5
  our_preds5 = new_our_preds5
  del new_our_preds5


  def map_score(old_score):
    return 1 + (old_score / 100) * 4


  our_preds1_1 = [map_score(l) for l in our_preds1_1]
  our_preds1_2 = [map_score(l) for l in our_preds1_2]
  our_preds2 = [map_score(l) for l in our_preds2]
  our_preds4 = [map_score(l) for l in our_preds4]
  our_preds5 = [map_score(l) for l in our_preds5]
  # ================= Debug (START) =================
  random.seed(12345)
  indices = random.sample(range(len(our_preds1_2)), NUM_EXAMPLES)
  validated_indices = indices.copy()

  if DEBUG == 1:
    print("***** This Is Debugging Setting !! ******")
    our_preds1_1 = [our_preds1_1[i] for i in indices]
    our_preds1_2 = [our_preds1_2[i] for i in indices]
    our_preds2 = [our_preds2[i] for i in indices]
    our_preds4 = [our_preds4[i] for i in indices]
    our_preds5 = [our_preds5[i] for i in indices]
    fixed_labels = [fixed_labels[i] for i in indices]
  elif DEBUG == 0:
      pass
  else:
    pass
  print(len(fixed_labels), len(our_preds1_1), len(our_preds2), len(our_preds4), len(our_preds5))

  # ================= Debug (END) =================


  our_preds_mapped1_1, our_preds_mapped1_2, our_preds_mapped2, our_preds_mapped3, our_preds_mapped4, our_preds_mapped5, our_preds_mapped_merged = [],[],[],[],[],[],[]

  for l in our_preds1_1:
      our_preds_mapped1_1.append(round(l))
  for l in our_preds1_2:
      our_preds_mapped1_2.append(round(l))
  for l in our_preds2:
    our_preds_mapped2.append(round(l))
  for l in our_preds4:
    our_preds_mapped4.append(round(l))
  for l in our_preds5:
    our_preds_mapped5.append(round(l))


  if DEBUG == 1:

    list_data = {
      'S1_1': our_preds_mapped1_1,
      'S1_2': our_preds_mapped1_2,
      'S2': our_preds_mapped4,
      'S3': our_preds_mapped2,
      'S4': our_preds_mapped5,
    }

    lists = list(list_data.values())
    names = list(list_data.keys())

    combinations_data = []

    for r in range(2, len(lists) + 1):
      for indices in itertools.combinations(range(len(lists)), r):
        combo_lists = [lists[i] for i in indices]
        combo_names = [names[i] for i in indices]

        avg_list = np.mean(combo_lists, axis=0)
        avg_list = avg_list.tolist()
        avg_list = [round(ll) for ll in avg_list]


        def compute(refs, preds):
          return stats.kendalltau(refs, preds).statistic, \
            stats.pearsonr(refs, preds).statistic, \
            stats.spearmanr(refs, preds).statistic


        kendalls, pearsons, spearmans = [], [], []
        kendall, pearson, spearman = compute(fixed_labels, avg_list)
        avg_cor = (kendall + spearman) / 2

        if 'S1_1' not in combo_names and 'S1_2' not in combo_names:
          pass
        else:
          combinations_data.append({
            'combination_names': combo_names,
            "combination": combo_lists,
            "merged": avg_list,
            "kendall": kendall,
            "pearson": pearson,
            "spearman": spearman,
            "avg_cor": avg_cor,
          })




    max_cor_combo = max(combinations_data, key=lambda x: x["avg_cor"])

    for one_name in list(list_data.keys()):
      selected_lists = [list_data[one_name]]

      avg_list = np.mean(selected_lists, axis=0)
      avg_list = avg_list.tolist()
      avg_list = [ll for ll in avg_list]

      def compute(refs, preds):
        return stats.kendalltau(refs, preds).statistic, \
          stats.pearsonr(refs, preds).statistic, \
          stats.spearmanr(refs, preds).statistic

      kendall, pearson, spearman = compute(fixed_labels, avg_list)
      avg_cor = (kendall + spearman) / 2


    with open('../results/summarization_selected.txt', 'w') as f:
        f.write('\n'.join(max_cor_combo['combination_names']))
    return {}


  else:
    with open(
      '../results/summarization_selected.txt',
      'r') as f:
      combination_names = f.readlines()
    combination_names = [ll.strip() for ll in combination_names]


    list_data = {
      'S1_1': our_preds_mapped1_1,
      'S1_2': our_preds_mapped1_2,
      'S2': our_preds_mapped4,
      'S3': our_preds_mapped2,
      'S4': our_preds_mapped5,
    }

    selected_lists = [list_data[name] for name in combination_names]
    avg_list = np.mean(selected_lists, axis=0)
    avg_list = avg_list.tolist()
    avg_list = [ll for ll in avg_list]


    def compute(refs, preds):
      return stats.kendalltau(refs, preds).statistic, \
        stats.pearsonr(refs, preds).statistic, \
        stats.spearmanr(refs, preds).statistic

    kendall, pearson, spearman = compute(fixed_labels, avg_list)
    avg_cor = (kendall + spearman) / 2




    return indices, avg_list, fixed_labels




## find the best team with 20 samples
main_summary(1)

# ## apply the best team with all rest data samples
RemoveSampleIndex, our_tool_preds, fixed_labels = main_summary(0)

averaged_labels = fixed_labels
all_uniq_preds_indexes = preds_indexes
individual_grades = [annotations_per_person[l] for l in all_uniq_preds_indexes]




annotator_to_labels = {}

for i in range(len(individual_grades)):
    g = individual_grades[i]
    for key_s in g:
      if key_s not in annotator_to_labels:
        annotator_to_labels[key_s] = []
      annotator_to_labels[key_s].append(  (i, g[key_s])  )



annotators_list = ['grader-'+ str(i+1) for i in range(len(list(set(annotator_names))))]
all_ids, all_labels = [],[]
for annotator in annotators_list:
  res = annotator_to_labels[annotator]
  sorted_res = sorted(res, key=lambda x: x[0])
  sorted_ids = [l[0] for l in sorted_res]
  all_ids.append(sorted_ids)
  all_labels.append([l[1] for l in sorted_res])



tool_preds_agreement = our_tool_preds
tool_preds_agreement_ids = list(range(len(tool_preds_agreement)))


for i_index in sorted(RemoveSampleIndex, reverse=True):
  _ = tool_preds_agreement.pop(i_index)
  _ = tool_preds_agreement_ids.pop(i_index)







def compute_average_kappa(annotations, annotation_ids, tolerance=1):
  def get_intersection_with_indices(list1, list2):
    set2 = set(list2)
    intersection = []

    for i, item in enumerate(list1):
      if item in set2:
        j = list2.index(item)
        intersection.append((item, i, j))
    return intersection

  annotator_pairs = list(combinations(range(len(annotations)), 2))
  kappa_scores = []
  kappa_t_scores = []
  for i, j in annotator_pairs:
    annotation_ids_1 = annotation_ids[i]
    annotation_ids_2 = annotation_ids[j]
    annotations_1 = annotations[i]
    annotations_2 = annotations[j]

    common_data_points =  get_intersection_with_indices(annotation_ids_1, annotation_ids_2)
    intersected_annotation1,intersected_annotation2 = [],[]
    for _, index_in_i, index_in_j in common_data_points:
      intersected_annotation1.append(annotations_1[index_in_i])
      intersected_annotation2.append(annotations_2[index_in_j])

    if len(intersected_annotation1) <= 5:
      continue



    intersected_annotation1 = [int(l) for l in intersected_annotation1]
    intersected_annotation2 = [int(l) for l in intersected_annotation2]
    kappa = cohen_kappa_score(intersected_annotation1, intersected_annotation2)
    kappa_tolerance = cohen_kappa_with_tolerance(intersected_annotation1, intersected_annotation2, tolerance)

    kappa_scores.append(kappa)
    kappa_t_scores.append(kappa_tolerance)


  return sum(kappa_scores) / len(kappa_scores), sum(kappa_t_scores) / len(kappa_t_scores), kappa_scores, kappa_t_scores

def compute_tool_human_kappa(human_annotations, human_annotation_ids, tool_annotation, tool_annotation_ids, tolerance=1):
  def get_intersection_with_indices(list1, list2):
    set2 = set(list2)
    intersection = []

    for i, item in enumerate(list1):
      if item in set2:
        j = list2.index(item)
        intersection.append((item, i, j))
    return intersection

  kappa_scores = []
  kappa_t_scores = []
  for i in range(len(human_annotations)):
    human_data = human_annotations[i]
    human_data_id = human_annotation_ids[i]

    common_data_points = get_intersection_with_indices(human_data_id, tool_annotation_ids)
    intersected_annotation1, intersected_annotation2 = [], []
    for _, index_in_i, index_in_j in common_data_points:
      intersected_annotation1.append(human_data[index_in_i])
      intersected_annotation2.append(tool_annotation[index_in_j])
    if len(intersected_annotation1) < 5:
      continue
    intersected_annotation1 = [int(l) for l in intersected_annotation1]
    intersected_annotation2 = [int(l) for l in intersected_annotation2]
    kappa = cohen_kappa_score(intersected_annotation1, intersected_annotation2)
    kappa_tolerance = cohen_kappa_with_tolerance(intersected_annotation1, intersected_annotation2, tolerance)

    kappa_scores.append(kappa)
    kappa_t_scores.append(kappa_tolerance)


  return sum(kappa_scores) / len(kappa_scores), sum(kappa_t_scores) / len(kappa_t_scores), kappa_scores, kappa_t_scores



human_annotations = all_labels
human_annotations_ids = all_ids
tool_annotation = [ l-1 for l in tool_preds_agreement]
tool_annotation_ids = tool_preds_agreement_ids


human_kappa, human_kappa_t, human_individual_kappa, _ = compute_average_kappa(human_annotations, human_annotations_ids)
print("Average Human-Human Cohen's Kappa:", human_kappa)


tool_human_kappa, tool_human_kappa_t, tool_human_individual_kappa, _ = compute_tool_human_kappa(human_annotations, human_annotations_ids, tool_annotation, tool_annotation_ids)
print("Average Tool-Human Cohen's Kappa:", tool_human_kappa)


