
import pandas as pd
import json, pickle, re
from scipy import stats
import itertools
import numpy as np
def main_apr(DEBUG_CHOICE):

  DEBUG = DEBUG_CHOICE

  label_data = pd.read_csv('../data/apr/bach_label.csv')
  annotator_ids = label_data['Annotator'].to_list()
  patch_ids = label_data['Patch'].to_list()
  answers = label_data['Answer'].to_list()

  patch_id_to_labels = {}
  for i in range(len(patch_ids)):
    annotator_id = annotator_ids[i]
    patch_id = patch_ids [i]
    answer = answers[i]
    if patch_id not in patch_id_to_labels:
      patch_id_to_labels[patch_id] = []
    patch_id_to_labels[patch_id].append( (annotator_id, answer)  )


  with open(
    '../data/apr/bach_data.pkl',
    'rb') as f:
    all_patch_id, all_project_name, all_bug_id, all_failed_tests, all_failed_tests_name_list, all_failed_tests_content_list, all_tests, all_human_patch, all_tool_patch_author_label, all_tool_patch = pickle.load(f)
    all_author_labels = all_tool_patch_author_label


  fixed_labels = []
  for i in range(len(all_patch_id)):
    patch_id = int(all_patch_id[i])
    mutil_annotator_results = patch_id_to_labels[patch_id]
    tool_author_label  = all_tool_patch_author_label[i].strip()
    maps = {'Y': 1, 'N': 0, '0': 0}
    votes = [maps[l[1]] for l in mutil_annotator_results]


    if votes.count(1) >= (len(votes)*0.5):
      fixed_labels.append(1)
    else:
      fixed_labels.append(0)

  with open(
    "../results/agent-score-direct_assess_no_gt-apr.pkl",
    "rb") as f:
    all_agents_scores1_1 = pickle.load(f)


  with open(
    "../results/agent-score-direct_assess-apr.pkl",
    "rb") as f:
    all_agents_scores1_2 = pickle.load(f)

  with open(
    "../results/agent-score-direct_compare-apr.pkl",
    "rb") as f:
    all_agents_scores2 = pickle.load(f)

  with open(
    "../results/agent-score-test_gene_reason-apr.pkl",
    "rb") as f:
    all_agents_scores3 = pickle.load(f)

  with open(
    "../results/agent-score-direct_assess_then_Validate-apr.pkl",
    "rb") as f:
    all_agents_scores4 = pickle.load(f)

  with open(
    "../results/agent-score-analyze_gt_then_validate-apr.pkl",
    "rb") as f:
    all_agents_scores5 = pickle.load(f)




  our_preds1_1, our_preds1_2, our_preds2, our_preds3, our_preds4, our_preds5 = [],[],[],[],[],[]

  for l in all_agents_scores1_1:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
    our_preds1_1.append(l)

  for l in all_agents_scores1_2:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
    our_preds1_2.append(l)

  for l in all_agents_scores2:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
    our_preds2.append(l)

  for l in all_agents_scores3:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
      if not isinstance(l, int):
        l = 0
    our_preds3.append(l)

  for l in all_agents_scores4:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
      if not isinstance(l, int):
        l = 0
    our_preds4.append(l)


  for l in all_agents_scores5:
    match = re.search(r'(\d+)\s*\[END\]', l)
    if match:
      l = int(match.group(1))
    else:
      l = l.split('[END]')[0].strip()
      if not isinstance(l, int):
        l = 0
    our_preds5.append(l)


  def map_score(old_score):
    return 0 + (old_score / 100) * 1


  our_preds1_1 = [map_score(l) for l in our_preds1_1]
  our_preds1_2 = [map_score(l) for l in our_preds1_2]
  our_preds2 = [map_score(l) for l in our_preds2]
  our_preds3 = [map_score(l) for l in our_preds3]
  our_preds4 = [map_score(l) for l in our_preds4]
  our_preds5 = [map_score(l) for l in our_preds5]


  import random
  random.seed(12345)
  NUM_EXAMPLES = 20
  indices = random.sample(range(len(our_preds1_1)), NUM_EXAMPLES)



  if DEBUG == 1:
    print("***** This Is Debugging Setting !! ******")

    our_preds1_1 = [our_preds1_1[i] for i in indices]
    our_preds1_2 = [our_preds1_2[i] for i in indices]
    our_preds2 = [our_preds2[i] for i in indices]
    our_preds3 = [our_preds3[i] for i in indices]
    our_preds4 = [our_preds4[i] for i in indices]
    our_preds5 = [our_preds5[i] for i in indices]
    fixed_labels = [fixed_labels[i] for i in indices]

  elif DEBUG == 0:
    print("***** This Is TEST Setting !! ******")

    our_preds1_1 = [our_preds1_1[i] for i in range(len(our_preds1_1)) if i not in indices]
    our_preds1_2= [our_preds1_2[i] for i in range(len(our_preds1_2)) if i not in indices]
    our_preds2 = [our_preds2[i] for i in range(len(our_preds2)) if i not in indices]
    our_preds3 = [our_preds3[i] for i in range(len(our_preds3)) if i not in indices]
    our_preds4 = [our_preds4[i] for i in range(len(our_preds4)) if i not in indices]
    our_preds5 = [our_preds5[i] for i in range(len(our_preds5)) if i not in indices]
    fixed_labels = [fixed_labels[i] for i in range(len(fixed_labels)) if i not in indices]
  else:
    pass


  if DEBUG == 1:

    list_data = {
      'S1_1': our_preds1_1,
      'S1_2': our_preds1_2,
      'S2': our_preds4,
      'S3': our_preds2,
      'S4': our_preds5,
      'S5': our_preds3,
    }


    lists = list(list_data.values())
    names = list(list_data.keys())

    combinations_data = []


    for r in range(2, len(lists) + 1):

      for indices in itertools.combinations(range(len(lists)), r):

        combo_lists = [lists[i] for i in indices]
        combo_names = [names[i] for i in indices]

        avg_list_ = np.mean(combo_lists, axis=0)
        avg_list_ = avg_list_.tolist()
        avg_list = []
        for ll in avg_list_:
          if ll>0.5:
            avg_list.append(1)
          else:
            avg_list.append(0)



        def compute(refs, preds):
          return stats.kendalltau(refs, preds).statistic, \
            stats.pearsonr(refs, preds).statistic, \
            stats.spearmanr(refs, preds).statistic

        # Correlation
        kendalls, pearsons, spearmans = [], [], []
        kendall, pearson, spearman = compute(fixed_labels, avg_list)
        avg_cor = (kendall + spearman) / 2

        if 'S1_1' not in combo_names and 'S1_2' not in combo_names:
          pass
        else:
          combinations_data.append({
            'combination_names': combo_names,
            "combination": combo_lists,
            "merged": avg_list,
            "kendall": kendall,
            "pearson": pearson,
            "spearman": spearman,
            "avg_cor": avg_cor,
          })

    max_cor_combo = max(combinations_data, key=lambda x: x["avg_cor"])

    with open('../results/apr_selected.txt', 'w') as f:
        f.write('\n'.join(max_cor_combo['combination_names']))

    return {}


  else:
    with open(
      '../results/apr_selected.txt',
      'r') as f:
      combination_names = f.readlines()
    combination_names = [ll.strip() for ll in combination_names]



    list_data = {
      'S1_1': our_preds1_1,
      'S1_2': our_preds1_2,
      'S2': our_preds4,
      'S3': our_preds2,
      'S4': our_preds5,
      'S5': our_preds3,
    }

    selected_lists = [list_data[name] for name in combination_names]
    avg_list_ = np.mean(selected_lists, axis=0)
    avg_list_ = avg_list_.tolist()
    avg_list = []
    for ll in avg_list_:
      if ll >0.5:
        avg_list.append(1)
      else:
        avg_list.append(0)



    def compute(refs, preds):
      return stats.kendalltau(refs, preds).statistic, \
        stats.pearsonr(refs, preds).statistic, \
        stats.spearmanr(refs, preds).statistic

    kendall, pearson, spearman = compute(fixed_labels, avg_list)
    avg_cor = (kendall + spearman) / 2
    print({'combination_names': combination_names, "kendall": round(kendall, 3),
    "spearman": round(spearman, 3), "avg_cor": round(avg_cor, 3)})






## find the best team with 20 samples
main_apr(1)

# # ## apply the best team with all rest data samples
main_apr(0)