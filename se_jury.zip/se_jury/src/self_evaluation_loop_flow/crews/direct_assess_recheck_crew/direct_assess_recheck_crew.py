from typing import Optional

from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from pydantic import BaseModel
# from self_evaluation_loop_flow.tools.CharacterCounterTool import CharacterCounterTool
from crewai.llm import LLM
import yaml

@CrewBase
class DirectAssessRecheckCrew:
    import os
    CUR_PATH = os.getcwd()
    config_path = CUR_PATH + '/exp.yaml'


    with open(config_path, 'r') as file:
      exp_setup = yaml.safe_load(file)

    agents_config = "config/agents_" + exp_setup["task"] + ".yaml"
    tasks_config = "config/tasks_" + exp_setup["task"] + ".yaml"


    @agent
    def direct_assess(self) -> Agent:
      return Agent(
        config=self.agents_config["direct_assess"],
        llm=LLM(model="gpt-4o-mini", temperature=0, max_tokens=10000, seed=42)
      )


    @agent
    def direct_assess_verifier(self) -> Agent:
        return Agent(
          config=self.agents_config["direct_assess_verifier"],
          llm=LLM(model="gpt-4o-mini", temperature=0, max_tokens=10000, seed=42)
        )

    @task
    def write_direct_assess(self) -> Task:
      return Task(
        config=self.tasks_config["write_direct_assess"],
      )


    @task
    def verify_direct_assess(self) -> Task:
        return Task(
            config=self.tasks_config["verify_direct_assess"],
            context=[self.write_direct_assess()]
        )

    @crew
    def crew(self) -> Crew:
        return Crew(
            agents=self.agents,
            tasks=self.tasks,
            process=Process.sequential,
            verbose=True,
        )
